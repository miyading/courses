cor(data$Max,data$Count)
plot(data$Max, data$Count)
summary(appendix)
summary(data)
length(appendix)
hist((1:nrow(appendix)), appendix$`Participants (Course Content Accessed)`)

#UBC course enrolment 
N<-5499
n<- 50
set.seed(10)
SRS.indices <-sample.int(N,  n, replace = F)
SRS.indices
SRS.sample <-data[SRS.indices, ]
ybar.srs <-mean(SRS.sample$Count) 
se.srs <-sqrt((1 -n / N) * var(SRS.sample$Count) / n)
srs <-c(ybar.srs, se.srs)

#Edx course enrolment
N2<-290
n2<- 50
set.seed(10)
SRS.indices2 <-sample.int(N2,  n2, replace = F)
SRS.sample2 <-appendix[SRS.indices2, ]
ybar.srs2 <-mean(SRS.sample2$`Participants (Course Content Accessed)`) 
se.srs2 <-sqrt((1 -n2 / N2) * var(SRS.sample2$`Participants (Course Content Accessed)`) / n2)
srs2 <-c(ybar.srs2, se.srs2)

#Estimate the population mean using STR with proportional allocationn.

#UBC course enrolment 
attach (data)
N.h <-tapply(Count, Campus, length)   #population size for different campus 
Campus <- names(N.h)
n.h.prop <-round( (N.h/N) * n) 

STR.sample.prop <-NULL
set.seed(10)

for (i in 1: length(Campus))
{ row.indices <-which(data$Campus == Campus[i])
sample.indices <-sample(row.indices, n.h.prop[i], replace = F)
sample.indices
STR.sample.prop <-rbind(STR.sample.prop, data[sample.indices, ])   }
ybar.h.prop <-tapply(STR.sample.prop$Count, STR.sample.prop$Campus, mean) 
var.h.prop <-tapply(STR.sample.prop$Count, STR.sample.prop$Campus, var) 
se.h.prop <-sqrt((1 -n.h.prop / N.h) * var.h.prop / n.h.prop)  
rbind(ybar.h.prop, se.h.prop)
ybar.str.prop <-sum(N.h / N * ybar.h.prop) 
se.str.prop <-sqrt(sum((N.h / N)^2 * se.h.prop^2)) 
str.prop <-c(ybar.str.prop, se.str.prop)

#Edx course enrolment
attach (appendix)
N.h2 <-tapply(`Participants (Course Content Accessed)`, Institution, length)   #population size for different Institution 
Institution <- names(N.h2)
n.h.prop2 <-round( (N.h2/N2) * n2) 

STR.sample.prop2 <-NULL
set.seed(10)

for (i in 1: length(Institution))
{ row.indices2 <-which(appendix$Institution == Institution[i])
sample.indices2 <-sample(row.indices2, n.h.prop2[i], replace = F)
STR.sample.prop2 <-rbind(STR.sample.prop2, appendix[sample.indices2, ])   }
ybar.h.prop2 <-tapply(STR.sample.prop2$`Participants (Course Content Accessed)`, STR.sample.prop2$Institution, mean) 
var.h.prop2 <-tapply(STR.sample.prop2$`Participants (Course Content Accessed)`, STR.sample.prop2$Institution, var) 
se.h.prop2 <-sqrt((1 -n.h.prop2 / N.h2) * var.h.prop2 / n.h.prop2)  
rbind(ybar.h.prop2, se.h.prop2)
ybar.str.prop2 <-sum(N.h2 / N2 * ybar.h.prop2) 
se.str.prop2 <-sqrt(sum((N.h2 / N2)^2 * se.h.prop2^2)) 
str.prop2 <-c(ybar.str.prop2, se.str.prop2)