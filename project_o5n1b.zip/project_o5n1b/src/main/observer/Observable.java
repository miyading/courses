package observer;

public class Observable {
}
