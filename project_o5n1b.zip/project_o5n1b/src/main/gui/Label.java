package gui;

import model.Repertoire;
import ui.FileSaveLoadManager;
import ui.Main;
import ui.UserInputManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class Label extends JFrame implements ActionListener {
    //private JLabel label;
    private JFrame frame = new JFrame("Repertoire App");
    private JTextField field;
    private JTextArea areaUrls;


    Label() throws IOException { //this is package private with no modifiers
        super("Web Movement Retrieve");

        Image image = ImageIO.read(
                getClass().getResource(
                        "mozart.jpg"));
       // setDefaultCloseOperation(EXIT_ON_CLOSE);
        setContentPane(new JLabel(new ImageIcon(image)));
        setPreferredSize(new Dimension(400,190));
//        ((JPanel) getContentPane()).setBorder(new EmptyBorder(13,13,13,13));

//        frame.setContentPane(new JLabel(new ImageIcon(image)));
//        frame.pack();
//        frame.setVisible(true);

        setLayout(new FlowLayout());
        JButton btn = new JButton("(Allegro, or Andante, etc.)");

        btn.setActionCommand("myButton1");
        btn.addActionListener(this);       // calling actionPerformed
        areaUrls = new JTextArea("You can start analyzing movements of Mozart Sonatas!");
        field = new JTextField(5);
        add(field);
        add(areaUrls);

        add(btn);
//        label = new JLabel("stub");
//        add(label);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(true);

    }

    // MODIFIES: this (especially areaURLs)
    // EFFECTS: updates label
    @Override
    public void actionPerformed(ActionEvent e) { //the update method parallel to java's Observer Pattern
        if (e.getActionCommand().equals("myButton1")) {
            try {
                FileSaveLoadManager fileSaveLoadManager
                        = new FileSaveLoadManager("inputfile.txt",
                        "urgentfile.txt");
                Repertoire rep = new Repertoire();

                UserInputManager userInputManager = new UserInputManager(rep);
                userInputManager.setMovement(field.getText());
                Main.userInputCallReadWeb(userInputManager);
                areaUrls.append(userInputManager.getStringBuilderToString());

               //label.setText(userInputManager.getStringBuilderToString());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}
