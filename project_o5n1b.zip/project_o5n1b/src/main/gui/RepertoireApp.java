package gui;

import exceptions.DupPiece;
import model.Piece;
import model.RegularPiece;
import model.Repertoire;
import model.UrgentPiece;
import ui.FileSaveLoadManager;
import ui.sound.Midi;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

public class RepertoireApp extends JFrame {

    private JPanel mainPanel;

    private JLabel pieceTypeLabel;
    private JLabel composerLabel;
    private JLabel titleLabel;
    private JLabel tempoLabel;
    private JLabel totalTimeLabel;
    private JLabel kindLabel;
    private JLabel repertoireLabel;

    private JButton pieceButton;
    private JButton soundButton;
    private JButton repertoireButton;
    private JButton soundCloseButton;

    private JTextField titleOfPiece;
    private JTextField tempoOfPiece;
    private JTextField totalTimeOfPiece;
    private JTextField kindOfPiece;
    private JTextField composer;
    private JButton webInfoButton;
    private JButton loadButton;
    private JButton saveButton;


    private Repertoire repertoire = new Repertoire();
    private Midi midi = new Midi();
    private String kind;
    private FileSaveLoadManager fileSaveLoadManager;

    public RepertoireApp(String title) {
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);


//        BufferedImage image = null;
//        try {
//            image = ImageIO.read(new File("chopin.jpg"));
//        } catch (IOException e) {
//            System.out.println("bad filename");
//        }
//        image.getScaledInstance(300, 500, Image.SCALE_SMOOTH);
//        setContentPane(new JLabel(new ImageIcon(image)));
        this.setContentPane(mainPanel);
        this.pack();
        setVisible(true);
        try {
            fileSaveLoadManager =
                    new FileSaveLoadManager("inputfile.txt",
                            "urgentfile.txt");
        } catch (IOException e1) {
            e1.printStackTrace();
        }


        pieceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //fileSaveLoadManager.load(repertoire);


                //grab the text from the textfields
                String composerName = composer.getText();
                String pieceTitle = titleOfPiece.getText();
                String tempoString = tempoOfPiece.getText();
                String totalTime = totalTimeOfPiece.getText();
                String kind = kindOfPiece.getText();
                Integer tempo = Integer.parseInt(tempoString);
                Integer time = Integer.parseInt(totalTime);


                setUpPiece(composerName, pieceTitle, kind, tempo, time);

//                fileSaveLoadManager.save(repertoire);


                //update the label
                //pieceTypeLabel.setText(repertoire.getPieces().toArray().toString());

//                pieceTypeLabel.setText(composerName + " " + pieceTitle + " "
// + tempoString + " " + totalTime + " " + kind);

                //System.out.println(repertoire.getUrgentKindPieces().get(0).getTitle());
//                if (kind.equalsIgnoreCase("Urgent")) {
//                    Integer lastIndex = repertoire.getUrgentKindPieces().size() - 1;
//                    Midi midi = new Midi();
//                    midi.sound(repertoire.getUrgentKindPieces().get(lastIndex).getTitle() + ".mid");
//                }
            }


        });

        soundButton.addActionListener(new ActionListener() {
            // REQUIRES: composer is one of chopin, bach, and joplin.
            @Override
            public void actionPerformed(ActionEvent e) {
                Integer lastUrgentPiece = repertoire.getUrgentKindPieces().size() - 1;
                kind = repertoire.getUrgentKindPieces().get(lastUrgentPiece).getKind();
                if (kind.equalsIgnoreCase("Urgent")) {
                    midi.sound(repertoire.getUrgentKindPieces().get(lastUrgentPiece).getName(),
                            repertoire.getUrgentKindPieces().get(lastUrgentPiece).getTitle() + ".mid");
                }
            }
        });

        repertoireButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String names = "";
                for (Piece piece: repertoire) {
                    names = names.concat("  " + piece.getTitle() + "    ");
                }
                repertoireLabel.setText(names);
            }
        });

        soundCloseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                midi.closeSound();
            }
        });

        webInfoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    new Label();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        });

        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fileSaveLoadManager.load(repertoire);
            }
        });

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fileSaveLoadManager.save(repertoire);
            }
        });
    }

    private void setUpPiece(String composerName, String pieceTitle, String kind, Integer tempo, Integer time) {
        if (kind.equalsIgnoreCase("regular")) {
            regularHelper(composerName, pieceTitle, kind, tempo, time);
        } else if (kind.equalsIgnoreCase("urgent")) {
            urgentHelper(composerName, pieceTitle, kind, tempo, time);
        } else {
            //System.out.println("wrong kind, retry regular or urgent");
            pieceTypeLabel.setText("wrong kind, retry regular or urgent");
        }
    }

    private void urgentHelper(String composerName, String pieceTitle, String kind, Integer tempo, Integer time) {
        try {
            repertoire.addPiece(new UrgentPiece(composerName, pieceTitle, tempo, time, kind));
            Integer lastUrgentPiece = repertoire.getUrgentKindPieces().size() - 1;
            pieceTypeLabel.setText(repertoire.getUrgentKindPieces().get(lastUrgentPiece).getTitle());
        } catch (DupPiece dupPiece) {
            dupPiece.printStackTrace();
        }
    }

    private void regularHelper(String composerName, String pieceTitle, String kind, Integer tempo, Integer time) {
        try {
            repertoire.addPiece(new RegularPiece(composerName, pieceTitle, tempo, time, kind));
            Integer lastRegularPiece = repertoire.getRegularKindPieces().size() - 1;
            pieceTypeLabel.setText(repertoire.getRegularKindPieces().get(lastRegularPiece).getTitle());
//                        System.out.println(repertoire.getPieces());
        } catch (DupPiece dupPiece) {
            dupPiece.printStackTrace();
        }
    }

}
