package model;

import java.util.Objects;

public abstract class Piece {
    protected String name;
    protected String title;
    protected int tempo;
    protected int totalTime;
    protected String kind;
    private Composer composer;

    public Piece(String name, String title, int tempo, int totalTime, String kind) {
        this.tempo = tempo;
        this.title = title;
        this.name = name;
        this.totalTime = totalTime;
        this.kind = kind;
    }


    // EFFECTS: get name of this piece, return this.name
    public String getName() {
        return this.name;
    }

    // EFFECTS: get title of this piece, return this.title
    public abstract String getTitle();

    // EFFECTS: get tempo of this piece, return this.tempo
    public int getTempo() {
        return this.tempo;
    }

    // EFFECTS: get totalTime of this piece, return this.totalTime
    public int getTotalTime() {
        return this.totalTime;
    }

    public String getKind() {
        return this.kind;
    }

    // MODIFIES: this, composer
    // EFFECTS: assign this given composer to this piece (call removeFromComposer to remove this piece from previous
    // composer if there was one.) then add this piece to composer.
    public void assignToComposer(Composer composer) {
        if (this.composer != composer) {
            removeFromComposer();
            this.composer = composer;
            composer.addPieceToComposer(this);

        }
    }

    // MODIFIES: this, composer
    // EFFECTS: if piece is assigned to a composer, then remove the piece from its previously assigned composer,
    // otherwise have no effect.
    public void removeFromComposer() {
        if (isAssignedToComposer()) {
            Composer c = getAssignedComposer();
            c.removePiece(this);

            name = null;
        }
    }

    private Composer getAssignedComposer() {
        return this.composer;
    }

    private boolean isAssignedToComposer() {
        if (getAssignedComposer() != null) {
            return true;
        }
        return false;
    }


    // EFFECTS: compares 2 piece s by title and kind
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Piece piece = (Piece) o;
        return Objects.equals(title, piece.title)
                && Objects.equals(kind, piece.kind);
    }

    // EFFECTS: changing hashcode to title and kind, comparing 2 piece s by title and kind alongside with equals
    @Override
    public int hashCode() {

        return Objects.hash(title, kind);
    }
}
