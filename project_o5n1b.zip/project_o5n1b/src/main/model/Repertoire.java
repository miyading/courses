package model;

import exceptions.DupPiece;
import exceptions.DupRegularPiece;
import exceptions.DupUrgentPiece;

import java.util.ArrayList;
import java.util.Iterator;


public class Repertoire implements Iterable<Piece> {

    // repertoire is one list of pieces made up of type regular piece or type urgent piece : Composer Name,
    // Title of RegularPiece, Tempo,
    // Total Practise Time of each Piece
    private ArrayList<Piece> pieces;


    // EFFECTS: constructs empty Repertoire
    public Repertoire() {
        pieces = new ArrayList<>();
    }

    // MODIFIES: this
    // EFFECTS: add a piece according to the typed-in kind: if kind is regular then a regular piece is created,
    // similar for urgent. Throws a specific duplication if piece is already in repertoire.
    public void addPiece(Piece p) throws DupPiece {
        boolean isRegular = p.getKind().equals("regular");
        if (isRegular) {
            for (int i = 0; i < pieces.size(); i++) {
                addPieceHelper(p, i, isRegular);
            }
        }
        if (!isRegular) {
            for (int i = 0; i < pieces.size(); i++) {
                addPieceHelper(p,i, isRegular);

            }
        }

       // System.out.println("New piece to consider/learn!");
        pieces.add(p);
    }


    private void addPieceHelper(Piece p, int i, Boolean b) throws DupPiece {
        if (b) {
            if (pieces.get(i).getTitle().equals(p.getTitle())) {
                //System.out.println("duplicated regular piece!");

                throw new DupRegularPiece();
            }
        }
        if (!b) {
            if (pieces.get(i).getTitle().equals(p.getTitle())) {
                //System.out.println("duplicated urgent piece!");

                throw new DupUrgentPiece();
            }
        }

    }

    public ArrayList<Piece> getPieces() {
        return pieces;
    }

    // EFFECTS: fetch all pieces of type regular piece from rep
    public ArrayList<RegularPiece> getRegularKindPieces() {
        int regularSize = 0;
        ArrayList<RegularPiece> regularPieces = new ArrayList<>();

        for (Piece piece : pieces) {
            if (piece.kind.equals("regular")) {
                regularSize++;
                regularPieces.add((RegularPiece)piece);
            }
        }
        return regularPieces;
    }

    // EFFECTS: fetch all pieces of type urgent piece from rep
    public ArrayList<UrgentPiece> getUrgentKindPieces() {
        int urgentSize = 0;
        ArrayList<UrgentPiece> urgentPieces = new ArrayList<>();

        for (Piece piece : pieces) {
            if (piece.kind.equals("urgent")) {
                urgentSize++;
                urgentPieces.add((UrgentPiece)piece);
            }
        }
        return urgentPieces;
    }

    // EFFECTS: allow for (Piece piece: Repertoire) {..} in Repertoire, traversing through all pieces in repertoire
    // without instantiating a list of pieces.
    @Override
    public Iterator<Piece> iterator() {
        return pieces.iterator();
    }
}
