package model;

import java.util.HashSet;
import java.util.Objects;

public class Composer {

    private String name;
    private String era;
    private HashSet<Piece> pieces;

    //EFFECTS: constructs composer with name and era
    public Composer(String name, String era) {
        this.name = name;
        this.era = era;
        pieces = new HashSet<>();
    }

    public String getName() {
        return this.name;
    }

    public String getEra() {
        return this.era;
    }

    // EFFECTS: returns an unmodifiable set of pieces composed by this composer that is in this program
    public HashSet<Piece> getPieces() {
        return pieces;
    }

    // MODIFIES: piece, this (specifically pieces)
    // EFFECTS: assign this piece to composer if this piece is not already in this composer's pieces
    public void addPieceToComposer(Piece piece) {
        if (!getPieces().contains(piece)) {
            pieces.add(piece);
            piece.assignToComposer(this);
        }
    }

    // MODIFIES: piece, this (specifically pieces)
    // EFFECTS: removes this piece from the composer if this composer's pieces list already contain this piece
    public void removePiece(Piece piece) {
        if (getPieces().contains(piece)) {
            pieces.remove(piece);
            piece.removeFromComposer();
        }
    }

    // EFFECTS: compares the composers by name, return true if equals, false otherwise
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Composer composer = (Composer) o; {
            return Objects.equals(name, composer.name);
        }
    }

    // EFFECTS: change hashCode alongside equals, comparing by composer name
    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
