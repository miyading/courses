package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ComposerPieceHashMap {

    private Map<Composer,ArrayList<String>> composerPieceMap = new HashMap<>();

    public ComposerPieceHashMap() {

        Composer chopin = new Composer("chopin","romantic");
        Composer bach  = new Composer("bach", "baroque");
        Composer joplin = new Composer("joplin", "jazz");

        addComposer(chopin);
        addComposer(bach);
        addComposer(joplin);

        addPiecesToComposer(chopin,"etude in c sharp minor");
        addPiecesToComposer(bach,"prelude in f sharp minor");
        addPiecesToComposer(joplin,"mapleleaf");
        addPiecesToComposer(joplin,"binks");

    }



    // EFFECTS: prints composer's name with more pieces to consider by this composer
    public String printComposerPieces(Composer composer) {
        System.out.println("Some more " + composer.getEra() + " pieces to consider written by "
                + composer.getName() + " are:");
        ArrayList<String> titleOfPieces = composerPieceMap.get(composer);
        String appendedTitles = "";
        for (String  title : titleOfPieces) {
            System.out.println("*****" + title);
            appendedTitles = appendedTitles + title;
        }
        return appendedTitles;
    }

    private void addComposer(Composer composer) {
        composerPieceMap.put(composer, new ArrayList<>());
    }

    private void addPiecesToComposer(Composer composer, String title) {
        ArrayList<String> titles = composerPieceMap.get(composer);
        titles.add(title);
    }

}
