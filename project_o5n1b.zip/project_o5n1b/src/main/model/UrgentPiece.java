package model;

import ui.Metronome;

public class UrgentPiece extends Piece {
    private Metronome metronome;

    public UrgentPiece(String name, String title, int tempo, int totalTime, String kind) {
        super(name, title, tempo, totalTime, kind);
        metronome = new Metronome(this.tempo, 4,10000); //having measure=4 here allow Tock *3 + Tick *1
    }


    // EFFECTS: could do something fancy with this title
    // (decide to not print out redundant things for simplicity, so the two getTitles are identical in
    // Urgent and Regular Piece)
    @Override
    public String getTitle() {
       // System.out.println("urgent:");
        return this.title;
    }

    // EFFECTS: a method for just urgent variation of RegularPiece
    //          Metronome called when it is an urgent piece that needs practicing
    public void displayTick(int time) {
        metronome.setDelay(time);
        metronome.start();
    }
}
