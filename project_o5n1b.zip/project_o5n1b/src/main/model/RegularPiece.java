package model;

public class RegularPiece extends Piece {

    public RegularPiece(String name, String title, int tempo, int totalTime, String kind) {
        super(name, title, tempo, totalTime, kind);
    }

    // Getters

    // EFFECTS: get title of this piece, return this.title
    @Override
    public String getTitle() {
        return this.title;
    }

}
