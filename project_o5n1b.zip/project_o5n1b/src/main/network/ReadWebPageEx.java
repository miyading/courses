package network;


//shamelessly quoting from: http://zetcode.com/articles/javareadwebpage/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ReadWebPageEx {

    private String weburls;
    private static final String newline = "\n";

    public String getWeburls() {
        return weburls;
    }

    // MODIFIES: this (specifically weburls)
    // EFFECTS: append given url to this weburls on a new line
    private void appendWeburls(String weburls) {
        this.weburls = this.weburls + newline + weburls;
    }


    // EFFECTS: find matching urls
    public void main(String movement) throws MalformedURLException, IOException {

        //System.out.println("Learn one new thing today about mozart sonatas, specifically " + movement +
        // " movements.");

        BufferedReader br = null;
        String regex = "\\b(https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]";
        Pattern p = Pattern.compile("<a href=(" + regex + ")>" + movement);

        //regex capture

        try {
            String theURL = "http://kern.humdrum.org/browse?l=mozart/sonatas"; //this can point to any URL
            URL url = new URL(theURL);
            br = new BufferedReader(new InputStreamReader(url.openStream()));

            String line;

            StringBuilder sb = new StringBuilder();
            findMatchingPattern(br, p);


         //   System.out.println(sb);
        } finally {

            if (br != null) {
                br.close();
            }
        }


    }

    private void findMatchingPattern(BufferedReader br, Pattern p) throws IOException {
        String line;//   boolean start = false;
        while ((line = br.readLine()) != null) {
            Matcher matcher = p.matcher(line);
            if (matcher.find()) { //if matcher can find pattern

                //System.out.println(matcher.group(1));
                appendWeburls(matcher.group(1));
            }
//                if (line.contains("Verovio Humdrum Viewer")) {
//                    start = true;
//                }
//                if (start) {
//                    sb.append(line);
//                    sb.append(System.lineSeparator());
//                }
//                if (line.equals("</table>")) {
//                    start = false;
//                }

        }
    }
}