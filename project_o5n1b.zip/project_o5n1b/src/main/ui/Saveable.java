package ui;

import model.Repertoire;

public interface Saveable {
    void save(Repertoire repertoire);
}
