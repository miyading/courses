package ui.sound;

import javax.sound.midi.*;
import java.io.File;
import java.io.IOException;

public class Midi {

    private Sequencer sequencer;

    // EFFECTS: play sound from given midi file
    public void sound(String composer, String pieceTitle) {
        //System.out.println("midi");

        try {
            sequencer = MidiSystem.getSequencer();
             // Get the default Sequencer
            if (sequencer == null) {
                System.err.println("Sequencer device not supported");
                return;
            }

            sequencer.open(); // Open device
            // Create sequence, the File must contain MIDI file data.
            Sequence sequence = MidiSystem.getSequence(new File("data/midi/" + composer + "/" + pieceTitle));
            sequencer.setSequence(sequence); // load it into sequencer
            sequencer.start();  // start the playback

        } catch (MidiUnavailableException | InvalidMidiDataException | IOException ex) {
            ex.printStackTrace();
        }
    }

    // EFFECTS: close sound of this midi file (can play another one using another sequencer)
    public void closeSound() {
        sequencer.close();
    }
}
