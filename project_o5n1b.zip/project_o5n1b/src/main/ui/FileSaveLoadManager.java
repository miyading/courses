package ui;

import exceptions.DupPiece;
import model.Piece;
import model.RegularPiece;
import model.Repertoire;
import model.UrgentPiece;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class FileSaveLoadManager implements Saveable, Loadable {
    private List<String> lines;
    private PrintWriter writer;
    private List<String> lines2;
    private PrintWriter writer2;


    public FileSaveLoadManager(String regularInputFileName, String urgentInputFileName) throws IOException {
        lines = Files.readAllLines(Paths.get(regularInputFileName));
        writer = new PrintWriter(regularInputFileName, "UTF-8");
        lines2 = Files.readAllLines(Paths.get(urgentInputFileName));
        writer2 = new PrintWriter(urgentInputFileName, "UTF-8");
    }

    // EFFECTS: save this given one repertoire to two files depending on kind
    public void save(Repertoire repertoire) {
        for (Piece p : repertoire.getPieces()) {
            String pieceInfo = p.getName() + "/" + p.getTitle() + "/" + p.getTempo() + "/" + p.getTotalTime() + "/"
                    + p.getKind();
            if (p.getKind().equals("regular")) {
                writer.println(pieceInfo);
              //  System.out.println("reached reg");
            }
            if (p.getKind().equals("urgent")) {
                writer2.println(pieceInfo);
               // System.out.println("reached urg");
            }
        }
        writer.close();
      //  System.out.println("reached reg close");
        writer2.close();
       // System.out.println("reached urg close");
    }

    private Piece makeAPiece(String kind, String name, String title, int tempo, int totalTime) {
        if (kind.equals("regular")) {
            return new RegularPiece(name, title, tempo, totalTime,kind);
        }
        if (kind.equals("urgent")) {
            return new UrgentPiece(name, title, tempo, totalTime,kind);
        }
        return null;
    }


    // EFFECTS: load both regular and urgent files to this newly instantiated repertoire passed in from RepertoireApp
    public void load(Repertoire repertoire) {
        regular(repertoire);
        urgent(repertoire);
    }

    private void regular(Repertoire repertoire) {
        for (String line : lines) {
            ArrayList<String> partsOfLine = splitOnSlash(line);

            String kind = partsOfLine.get(4);

            Piece p = setupPieceLoad(line, kind);
            try {
                repertoire.addPiece(p);
            } catch (DupPiece dupPiece) {
                dupPiece.printStackTrace();
            }
//            finally {
//               // System.out.println("loadRegular");
//            }
        }
    }

    private void urgent(Repertoire repertoire) {
        for  (String line : lines2) {
            ArrayList<String> partsOfLine = splitOnSlash(line);

            String kind = partsOfLine.get(4);

            Piece p = setupPieceLoad(line, kind);
            try {
                repertoire.addPiece(p);
            } catch (DupPiece dupPiece) {
                dupPiece.printStackTrace();
            }
//            finally {
//                //System.out.println("loadUrgent");
//            }
        }
    }

    private Piece setupPieceLoad(String line, String regular) {
        ArrayList<String> partsOfLine = splitOnSlash(line);
        String name = partsOfLine.get(0);
        String title = partsOfLine.get(1);
        int tempo = Integer.parseInt(partsOfLine.get(2));
        int totalTime = Integer.parseInt(partsOfLine.get(3));
        return makeAPiece(regular, name, title, tempo, totalTime);
    }

    private static ArrayList<String> splitOnSlash(String line) {
        String[] splits = line.split("/");
        return new ArrayList<>(Arrays.asList(splits));
    }
}
