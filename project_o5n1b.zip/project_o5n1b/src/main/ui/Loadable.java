package ui;

import model.Repertoire;

public interface Loadable {
    void load(Repertoire repertoire);
}
