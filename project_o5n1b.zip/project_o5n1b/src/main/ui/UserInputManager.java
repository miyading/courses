package ui;

import exceptions.DupPiece;
import model.Piece;
import model.RegularPiece;
import model.Repertoire;
import model.UrgentPiece;
import network.ReadWebPageEx;

import java.io.IOException;
import java.util.Scanner;

public class UserInputManager {

    private String name = null;
    private String title = null;
    private int tempo = 0;
    private int totalTime = 0;
    private String userAnswer = "";
    private Repertoire repertoire;
    private int selection;
    private int time;
    private String kind;
    private String movement;
    private String weburls;

    private String a1 = "What is the name of the composer that you want to play?";
    private String a2 = "What is the title of the piece that you want to play?";
    private String a3 = "What is the tempo of the piece that you want to play?";
    private String a4 = "What is the total time you need to be able to play the piece fluently (unit: hours)?";
    private String a5 = "Is there another piece that you want to add to your repertoire? Answer 'yes' or 'no' to quit";
    private String a6 = "";
    private String a7 = "The piece(s) that you want to play is(are): ";
    private String a8 = "Would you like to make a regular piece (0) or an urgent piece (1)?";


    public UserInputManager(Repertoire repertoire) {
        this.repertoire = repertoire;
    }

    // MODIFIES: piece, repertoire
    // EFFECTS: interact with user: 1. CREATE and 2. DISPLAY piece(s), also 3. EDIT, 4. ARCHIVE, 5. QUIT in later weeks.
    public void interact() {

        while (!userAnswer.equalsIgnoreCase("no")) {

            print(a1);
            name = getAnswer();
            print(a2);
            title = getAnswer();
            print(a3);
            tempo = Integer.parseInt(getAnswer()); // convert string to int
            print(a4);
            totalTime = Integer.parseInt(getAnswer()); // convert string to int

            print(a8);

            selection = Integer.parseInt(getAnswer());
            if (selection == 0) {
                kind = "regular";
            } else if (selection == 1) {
                kind = "urgent";
            }
            createDisplayPiece(kind);

        }
    }

    public String getMovement() {
        return movement;
    }

    public String getStringBuilderToString() {
        return weburls;
    }



    public void setMovement(String movement) {
        this.movement = movement;
    }

    // MODIFIES: this (specifically weburls)
    // EFFECTS: obtain URLs
    public void webInputMovement() {
        // print("What tempo marking are you interested in exploring in Mozart Sonatas? (Allegro, or Andante, etc.)");
        // movement = getAnswer(); // now using getText instead
        ReadWebPageEx readWebPageEx = new ReadWebPageEx();
        try {
            readWebPageEx.main(movement);
            weburls = readWebPageEx.getWeburls();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    // MODIFIES: this (specifically time)
    // EFFECTS: obtain time in ms that want the metronome to play for, as part of the interaction loop
    public int askForTimeInMs() {
        print("How long (ms) should the metronome play for");
        time = Integer.parseInt(getAnswer());
        return time;

    }

    private void createDisplayPiece(String kind) {
        try {
            if (kind.equals("regular")) {
                choice1();
            } else if (kind.equals("urgent")) {
                choice2();
            }
        } catch (DupPiece dupPiece) {
            dupPiece.printStackTrace();
        } finally {
            displayChoice();
        }
    }


    private void choice1() throws DupPiece {
        createRegularPiece();
    }

    private void choice2() throws DupPiece {
        createUrgentPiece();

    }

    private void displayChoice() {
        displayPieces();
        print(a5);
        userAnswer = getAnswer();
    }

    // EFFECTS: display the piece(s) in rep
    private void displayPieces() {

        print(a7);

        for (int i = 0; i < repertoire.getPieces().size(); i++) {
            Piece currentPiece = repertoire.getPieces().get(i);
            String title = currentPiece.getTitle();
            String name = currentPiece.getName();
            int tempo = currentPiece.getTempo();
            int totalTime = currentPiece.getTotalTime();
            String kind = currentPiece.getKind();
            String pieceInfo = name + ", " + title + ", " + tempo + " bpm, " + totalTime
                    + " hours of practice." + "---" + kind;
            System.out.println(pieceInfo);
        }
    }


    private void createUrgentPiece() throws DupPiece {
        UrgentPiece urgentPiece = new UrgentPiece(name, title, tempo, totalTime, kind);
        repertoire.addPiece(urgentPiece);

    }

    // MODIFIES: piece, repertoire
    // EFFECTS: create a piece and add into repertoire
    private void createRegularPiece() throws DupPiece {
        RegularPiece regularPiece = new RegularPiece(name, title, tempo, totalTime, kind);
        repertoire.addPiece(regularPiece);

    }

    // EFFECTS: print out interact
    private void print(String string) {
        System.out.println(string);
    }

    // EFFECTS: get answer from user, return user answer
    private String getAnswer() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
}
