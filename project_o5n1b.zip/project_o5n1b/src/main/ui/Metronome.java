package ui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Metronome {
    double bpm;
    int measure;
    int counter;
    boolean status;
    private Timer timer;



    public Metronome(double bpm, int measure, int time) {
        timer = new Timer(time, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                status = false;
            }
        });
        timer.setInitialDelay(time);
        timer.setRepeats(false);
        this.bpm = bpm;
        this.measure = measure;
        status = true;
    }

    // EFFECTS: imitate metronome by displaying tick tock at this.bpm and rhythm 3/4 or 4/4, etc.
    public void start() {
        timer.start();
        while (status) {
            try {
                Thread.sleep((long) (1000 * (60.0 / bpm)));
                // the first/last urgent piece's tempo from the urgent piece file determines the tempo,
                // depending on how we called display tick in main
                // 1000 is just default
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            counter++;
            if (counter % measure == 0) {
                System.out.println("TICK");
            } else {
                System.out.println("TOCK");
            }
        }
    }

    //EFFECTS: sets delay
    public void setDelay(int time) {
        timer.setInitialDelay(time);
    }
}
