package ui;

import gui.RepertoireApp;
import model.Composer;
import model.ComposerPieceHashMap;
import model.Repertoire;
import model.UrgentPiece;
import ui.sound.Midi;

import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
//        new Label();
        new RepertoireApp("Repertoire App");

//        FileSaveLoadManager fileSaveLoadManager
//                = new FileSaveLoadManager("inputfile.txt", "urgentfile.txt");
//        Repertoire rep = new Repertoire();
//
//        userInputCallReadWeb(rep);
//
//        loadFile(fileSaveLoadManager, rep);
//
//        UserInputManager userInputManager = addToDOsAndSaveFile(fileSaveLoadManager, rep);
//
//        UrgentPiece lastUrgPiece = lastUrgentPieceCoolStuff(rep, userInputManager);
//
//        composerPiecesDisplay(lastUrgPiece);

    }

    private static UrgentPiece lastUrgentPieceCoolStuff(Repertoire rep, UserInputManager userInputManager) {
        Midi midi = new Midi();
        midi.sound(rep.getUrgentKindPieces().get(rep.getUrgentKindPieces().size() - 1).getName(),
                rep.getUrgentKindPieces().get(rep.getUrgentKindPieces().size() - 1).getTitle() + ".mid");

        UrgentPiece lastUrgPiece = rep.getUrgentKindPieces().get(rep.getUrgentKindPieces().size() - 1);

        int time = userInputManager.askForTimeInMs();
        lastUrgPiece.displayTick(time);
        midi.closeSound();
        return lastUrgPiece;
    }

    private static void loadFile(FileSaveLoadManager fileSaveLoadManager, Repertoire rep) {
        fileSaveLoadManager.load(rep);
        System.out.println("number of regular pieces = " + rep.getRegularKindPieces().size());
        System.out.println("number of urgent pieces = " + rep.getUrgentKindPieces().size());
    }

    // REQUIRES: require movement type to be one of Andante, Allegro, ...
    //          (see craig's webpage for which movement is involved)
    // EFFECTS: calls UserInputManager.webInputMovement to obtain weburls
    public static void userInputCallReadWeb(UserInputManager userInputManager) {
        //UserInputManager webUserInputManager = new UserInputManager(rep);
        userInputManager.webInputMovement();
    }


    private static UserInputManager addToDOsAndSaveFile(FileSaveLoadManager fileSaveLoadManager, Repertoire rep) {
        UserInputManager userInputManager = new UserInputManager(rep);
        userInputManager.interact();
        fileSaveLoadManager.save(rep);
        System.out.println("number of regular pieces = " + rep.getRegularKindPieces().size());
        System.out.println("number of urgent pieces = " + rep.getUrgentKindPieces().size());
        return userInputManager;
    }

    private static void composerPiecesDisplay(UrgentPiece lastUrgPiece) {
        ComposerPieceHashMap composerPieceHashMap = new ComposerPieceHashMap();
        Composer composer = new Composer("Joplin", "jazz");
        composer.addPieceToComposer(lastUrgPiece);
        System.out.println("pieces in your rep by " + composer.getName() + " are:"
                + composer.getPieces().iterator().next().getTitle());
        composerPieceHashMap.printComposerPieces(new Composer(lastUrgPiece.getName(),"jazz"));
    }

}
