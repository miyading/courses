package exceptions;

public class DupPiece extends Exception{
}
