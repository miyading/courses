package exceptions;

public class DupUrgentPiece extends DupPiece{
}
