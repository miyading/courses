package exceptions;

public class DupRegularPiece extends DupPiece{
}
