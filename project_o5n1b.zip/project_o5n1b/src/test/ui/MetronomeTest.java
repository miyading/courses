package ui;

import org.junit.jupiter.api.Test;

public class MetronomeTest {

    @Test
    void testMetronome() {
        Metronome metronome1 = new Metronome(120,4,5000);
        metronome1.start();
    }
}

