package ui;

class UserInputManagerTest {
//    UserInputManager userInputManager;
//
//    @BeforeEach
//    public void runBefore() throws IOException {
//        FileSaveLoadManager fileSaveLoadManager
//                = new FileSaveLoadManager("regularFileTest.txt", "urgentFileTest");
//        Repertoire repertoire = new Repertoire();
//        fileSaveLoadManager.loadRegular(repertoire);
//        userInputManager = new UserInputManager(repertoire);
//    }
//
//
//
//
//    private void CreateTarget(Repertoire r, String[] nameArray, String[] titleArray, int[] tempArray, int[]timeArray) {
//        for (int i = 0; i < nameArray.length; i++) {
//            RegularPiece temp = new RegularPiece(nameArray[i], titleArray[i], tempArray[i], timeArray[i]);
//            try {
//                r.addRegularPiece(temp);
//            } catch (DupRegularPiece dupRegularPiece) {
//                dupRegularPiece.printStackTrace();
//            }
//        }
//    }
//
//    @Test
//    public void testConstructor() {
//
//        String[] nameArray = {"name1", "name2", "name3", "name4"};
//        String[] titleArray = {"title1", "title2", "title3", "title4"};
//        int[] tempArray = {1, 2, 3, 4};
//        int[] totaltimeArray = {10, 20, 30, 40};
//
//
//        Repertoire rep = new Repertoire();
//        CreateTarget(rep, nameArray, titleArray, tempArray, totaltimeArray);
//        assertEquals(4, rep.getRegularPieces().size());
//    }
//
//    @Test
//    public void testDisplayPieceOneDuplicate() {
//
//        String[] nameArray = {"name1", "name2", "name3", "name4"};
//        String[] titleArray = {"title1", "title1", "title3", "title4"};
//        int[] tempArray = {1, 2, 3, 4};
//        int[] totaltimeArray = {10, 20, 30, 40};
//        Repertoire rep = new Repertoire();
//        CreateTarget(rep, nameArray, titleArray, tempArray, totaltimeArray);
//        RegularPiece one = rep.getRegularPieces().get(0);
//        RegularPiece two = rep.getRegularPieces().get(1);
//        RegularPiece three = rep.getRegularPieces().get(2);
//        assertEquals(rep.getRegularPieces().size(), 3);
//        assertEquals(one.getName(), nameArray[0]);
//        assertEquals(two.getName(), nameArray[2]);
//        assertEquals(three.getName(), nameArray[3]);
//        assertEquals(one.getTitle(), titleArray[0]);
//        assertEquals(two.getTitle(), titleArray[2]);
//        assertEquals(three.getTitle(), titleArray[3]);
//    }
//    @Test
//    public void testDisplayPieceNoDuplicate() {
//
//        String[] nameArray = {"name1", "name2", "name3", "name4"};
//        String[] titleArray = {"title1", "title2", "title3", "title4"};
//        int[] tempArray = {1, 2, 3, 4};
//        int[] totaltimeArray = {10, 20, 30, 40};
//        Repertoire rep = new Repertoire();
//        CreateTarget(rep, nameArray, titleArray, tempArray, totaltimeArray);
//        RegularPiece one = rep.getRegularPieces().get(0);
//        RegularPiece two = rep.getRegularPieces().get(1);
//        RegularPiece three = rep.getRegularPieces().get(2);
//        RegularPiece four = rep.getRegularPieces().get(3);
//        assertEquals(rep.getRegularPieces().size(), 4);
//        assertEquals(one.getName(), nameArray[0]);
//        assertEquals(two.getName(), nameArray[1]);
//        assertEquals(three.getName(), nameArray[2]);
//        assertEquals(four.getName(), nameArray[3]);
//        assertEquals(one.getTitle(), titleArray[0]);
//        assertEquals(two.getTitle(), titleArray[1]);
//        assertEquals(three.getTitle(), titleArray[2]);
//        assertEquals(four.getTitle(), titleArray[3]);
//    }
//
//    @Test
//    public void testDisplayPieceAllDuplicate() {
//
//        String[] nameArray = {"name1", "name2", "name3", "name4"};
//        String[] titleArray = {"title1", "title1", "title1", "title1"};
//        int[] tempArray = {1, 2, 3, 4};
//        int[] totaltimeArray = {10, 20, 30, 40};
//        Repertoire rep = new Repertoire();
//        CreateTarget(rep, nameArray, titleArray, tempArray, totaltimeArray);
//        RegularPiece one = rep.getRegularPieces().get(0);
//        assertEquals(rep.getRegularPieces().size(), 1);
//        assertEquals(one.getName(), nameArray[0]);
//        assertEquals(one.getTitle(), titleArray[0]);
//
//
////        for (int i = 0; i < rep.getRegularPieces().size(); i++) {
////            RegularPiece temp = (RegularPiece) rep.getRegularPieces().get(i);
////            assertEquals(temp.getName(), nameArray[i]);
////            assertEquals(temp.getTitle(), titleArray[i]);
////            assertEquals(temp.getTempo(), tempArray[i]);
////            assertEquals(temp.getTotalTime(), totaltimeArray[i]);
////        }
//    }
//
//
//
////    @Test
////
////    public void testCreatePieceNoDuplicate(){
////        Repertoire rep = new Repertoire();
////        RegularPiece A = new RegularPiece ("name1", "title1", 0, 0);
////        RegularPiece B = new RegularPiece ("name2", "title2", 0, 0);
////        RegularPiece C = new RegularPiece ("name3", "title3", 0, 0);
////        RegularPiece D = new RegularPiece ("name4", "title4", 0, 0);
////        RegularPiece E = new RegularPiece ("name5", "title5", 0, 0);
////        rep.addRegularPiece(A);
////        rep.addRegularPiece(B);
////        rep.addRegularPiece(C);
////        rep.addRegularPiece(D);
////        rep.addRegularPiece(E);
////
////        boolean checkTitle = false;
////        for(int i=0;i<rep.getRegularPieces().size();i++){
////            RegularPiece currPiece = (RegularPiece) rep.getRegularPieces().get(i);
////            String title = currPiece.getTitle(); //String name = rep.getRegularPieces().get(i).getName();
////            switch(title){
////                case "title1":  checkTitle = true; break; //else if else if
////                case "title2":  checkTitle = true; break;
////                case "title3":  checkTitle = true; break;
////                case "title4":  checkTitle = true; break;
////                case "title5":  checkTitle = true; break;
////                default: break;
////            }
////
////            assertTrue(checkTitle);
////        }
////
////        assertEquals(rep.getRegularPieces().size(),5);
////    }
////
////    @Test
////
////    public void testCreatePieceAllDuplicate(){
////        Repertoire rep = new Repertoire();
////        RegularPiece A = new RegularPiece ("name1", "title1", 0, 0);
////        RegularPiece B = new RegularPiece ("name2", "title1", 0, 0);
////        RegularPiece C = new RegularPiece ("name3", "title1", 0, 0);
////        RegularPiece D = new RegularPiece ("name4", "title1", 0, 0);
////        RegularPiece E = new RegularPiece ("name5", "title1", 0, 0);
////        rep.addRegularPiece(A);
////        rep.addRegularPiece(B);
////        rep.addRegularPiece(C);
////        rep.addRegularPiece(D);
////        rep.addRegularPiece(E);
////
////
////boolean checkTitle = false;
////        for(int i=0;i<rep.getRegularPieces().size();i++){
////            RegularPiece currPiece = (RegularPiece) rep.getRegularPieces().get(i);
////            String title = currPiece.getTitle(); //String name = rep.getRegularPieces().get(i).getName();
////            switch(title){
////                case "title1":  checkTitle = true; break; //else if else if
////                case "title2":  checkTitle = true; break;
////                case "title3":  checkTitle = true; break;
////                case "title4":  checkTitle = true; break;
////                case "title5":  checkTitle = true; break;
////                default: break;
////            }
////
////            assertTrue(checkTitle);
////        }
////
////
////        assertEquals(rep.getRegularPieces().size(),1);
////    }
//
////    @Test
////
////    public void testCreatePieceWithDuplicate() {
////        Repertoire rep = new Repertoire();
////        RegularPiece A = new RegularPiece("name1", "title1", 0, 0);
////        RegularPiece B = new RegularPiece("name1", "title1", 0, 0);
////        RegularPiece C = new RegularPiece("name2", "title2", 0, 0);
////        RegularPiece D = new RegularPiece("name3", "title3", 0, 0);
////        RegularPiece E = new RegularPiece("name4", "title4", 0, 0);
////        rep.addRegularPiece(A);
////        rep.addRegularPiece(B);
////        rep.addRegularPiece(C);
////        rep.addRegularPiece(D);
////        rep.addRegularPiece(E);
////
////        boolean checkTitle = false;
////        for (int i = 0; i < rep.getRegularPieces().size(); i++) {
////            RegularPiece currPiece = (RegularPiece) rep.getRegularPieces().get(i);
////            String title = currPiece.getTitle(); //String name = rep.getRegularPieces().get(i).getName();
////            switch (title) {
////                case "title1":
////                    checkTitle = true;
////                    break; //else if else if
////                case "title2":
////                    checkTitle = true;
////                    break;
////                case "title3":
////                    checkTitle = true;
////                    break;
////                case "title4":
////                    checkTitle = true;
////                    break;
////                default:
////                    break;
////            }
////
////            assertTrue(checkTitle);
////        }
////
////
////        assertEquals(rep.getRegularPieces().size(), 4);
////    }
////
////
}



