package ui;

public class FileSaveLoadManagerTest {
//    RegularPiece piecetest = new RegularPiece("a", "b", 7,9);
//    RegularPiece piecetest2 = new RegularPiece("n", "m", 9,2);
//    private ArrayList<RegularPiece> reptest;
//    private Repertoire repertoire = new Repertoire();
//    FileSaveLoadManager fileSaveLoadManagertest
//            = new FileSaveLoadManager("regularFileTest","urgentFileTest");
//
//    public FileSaveLoadManagerTest() throws IOException {
//    }
//
//
//    @Test
//    public void testLoad() {
//        fileSaveLoadManagertest.loadRegular(repertoire);
//        assertEquals(repertoire.getRegularPieces().get(0).getName(),"debussy");
////        assertEquals(fileSaveLoadManagertest.loadRegular(repertoire).getRegularPieces().get(0).getName(),"debussy");
//    }
//
//    @Test
//    public void testSave() {
//        fileSaveLoadManagertest.loadRegular(repertoire);
//        fileSaveLoadManagertest.saveRegular(repertoire);
//        assertEquals(repertoire.getRegularPieces().get(0).getName(),"debussy");
//    }
}
