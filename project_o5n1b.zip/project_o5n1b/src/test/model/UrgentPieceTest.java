package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class UrgentPieceTest extends PieceTest {
    UrgentPiece urgentPiece;


    @BeforeEach
    public void runBefore() {
        pieceTest = new UrgentPiece("","",0,0,"");
        urgentPiece = new UrgentPiece("","",90,23,"urgent");

    }
//call getters from Piece
    @Test
    public void getTitleTest() {
      assertEquals(pieceTest.getTitle(),"");
    }


    @Test
    public void displayTickTest() {

    }
}