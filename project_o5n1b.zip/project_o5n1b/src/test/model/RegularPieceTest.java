package model;


import org.junit.jupiter.api.BeforeEach;

public class RegularPieceTest extends PieceTest {


    @BeforeEach
    public void runBefore() {
        pieceTest = new RegularPiece("", "", 0, 0,"");
    }

}
