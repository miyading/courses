package model;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ComposerTest {
    private Composer composer;
    private Piece piece;
    private Piece piece2;

    @BeforeEach
    public void runBefore() {
        composer = new Composer("chopin", "romantic");
        piece = new RegularPiece("chopin","revoluntionary",90,50,"regular");
        piece2 = new RegularPiece("chopin", "sunshine", 180,70,"regular");
    }

    @Test
    public void getComposerNameTest() {
        assertEquals(composer.getName(), "chopin");
    }

    @Test
    public void getComposerEraTest() {
        assertEquals(composer.getEra(), "romantic");
    }

    @Test
    public void addPieceTest() {
        composer.addPieceToComposer(piece);
        assertEquals(composer.getPieces().size(),1);
    }

    @Test
    public void addTwoPiecesTest() {
        composer.addPieceToComposer(piece);
        composer.addPieceToComposer(piece2);
        assertEquals(composer.getPieces().size(),2);
    }

    @Test
    public void removePieceTest() {
        composer.addPieceToComposer(piece);
        composer.removePiece(piece);
        assertEquals(composer.getPieces().size(),0);
    }

    @Test
    public void removeSomePieceTest() {
        composer.addPieceToComposer(piece);
        composer.addPieceToComposer(piece2);
        composer.removePiece(piece);
        assertEquals(composer.getPieces().size(),1);
        assertTrue(composer.getPieces().contains(piece2));
    }

    @Test
    public void removeAllPieceTest() {
        composer.addPieceToComposer(piece);
        composer.addPieceToComposer(piece2);
        composer.removePiece(piece);
        composer.removePiece(piece2);
        assertEquals(composer.getPieces().size(),0);
        assertFalse(composer.getPieces().contains(piece2));
    }
}
