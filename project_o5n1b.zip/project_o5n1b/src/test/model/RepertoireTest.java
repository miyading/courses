package model;

import exceptions.DupPiece;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class RepertoireTest {
    //user should not be able to manipulate the field, but test is for yourself so do not need private/public
    Piece piece1;
    Piece piece2;
    Piece piece3;
    Piece piece4;
    //RegularPiece regularPiece;
    //UrgentPiece urgentPiece;
    Repertoire repertoire;

    @BeforeEach
    void setUpTests() {
        //regularPiece = new RegularPiece("chopin", "etude", 90,10,"regular");
       // urgentPiece = new UrgentPiece("bach", "prelude", 80,12,"urgent");
        repertoire = new Repertoire();
        piece1 = new RegularPiece("joplin","mapleleaf",90,12,"regular");
        piece2 = new UrgentPiece("bach", "prelude", 80,12,"urgent");
        piece3 = new RegularPiece("chopin", "etude", 95,14,"regular");
        piece4 = new UrgentPiece("joplin", "binks", 120,15,"urgent");
    }

    //Test for generic Piece
    @Test
    void testAddOneRegularPiece() {
        try {
            repertoire.addPiece(piece1);
        } catch (DupPiece dupPiece) {
            fail("Should not have a duplication when there is no duplicated piece1");
        }
        assertEquals(repertoire.getPieces().get(0).getName(), "joplin");
        assertEquals(repertoire.getPieces().get(0).getTitle(), "mapleleaf");
        assertEquals(repertoire.getPieces().get(0).getTempo(), 90);
        assertEquals(repertoire.getPieces().get(0).getTotalTime(), 12);
        assertEquals(repertoire.getPieces().get(0).getKind(),"regular");

        assertEquals(repertoire.getRegularKindPieces().get(0), piece1);
    }

    @Test
    void testAddOneUrgentPiece() {
        try {
            repertoire.addPiece(piece2);
        } catch (DupPiece dupPiece) {
            fail("Should not have a duplication when there is no duplicated piece");
        }
        assertEquals(repertoire.getPieces().get(0).getName(), "bach");
        assertEquals(repertoire.getPieces().get(0).getTitle(), "prelude");
        assertEquals(repertoire.getPieces().get(0).getTempo(), 80);
        assertEquals(repertoire.getPieces().get(0).getTotalTime(), 12);
        assertEquals(repertoire.getPieces().get(0).getKind(),"urgent");

        assertEquals(repertoire.getUrgentKindPieces().get(0), piece2);
    }

    @Test
    void testAddTwoNonDuplicatedRegularPieces() {
        try {
            repertoire.addPiece(piece1);
            repertoire.addPiece(piece3);

        } catch (DupPiece dupPiece) {
            fail("Should not have a duplication when there is no duplicated piece");
        }

        assertEquals(repertoire.getRegularKindPieces().get(0), piece1);
        assertEquals(repertoire.getRegularKindPieces().get(1), piece3);
    }

    @Test
    void testAddTwoDuplicatedRegularPieces() {
        try {
            repertoire.addPiece(piece1);
            repertoire.addPiece(piece1);

        } catch (DupPiece dupPiece) {
            System.out.println("caught the duplication");
        }

        assertEquals(repertoire.getPieces().size(),1);
        assertEquals(repertoire.getRegularKindPieces().size(), 1);
        assertEquals(repertoire.getUrgentKindPieces().size(),0);
    }

    @Test
    void testAddTwoDuplicatedUrgentPieces() {
        try {
            repertoire.addPiece(piece2);
            repertoire.addPiece(piece2);

        } catch (DupPiece dupPiece) {
            System.out.println("caught the duplication");
        }

        assertEquals(repertoire.getPieces().size(),1);
        assertEquals(repertoire.getRegularKindPieces().size(), 0);
        assertEquals(repertoire.getUrgentKindPieces().size(), 1);
    }

    @Test
    void testAddBothKindNonDuplicatedPieces() {
        try {
            repertoire.addPiece(piece1);
            repertoire.addPiece(piece2);
            repertoire.addPiece(piece3);
            repertoire.addPiece(piece4);

        } catch (DupPiece dupPiece) {
            fail("Should not have a duplication when there is no duplicated piece");
        }

        assertEquals(repertoire.getPieces().size(),4);
        assertEquals(repertoire.getRegularKindPieces().size(), 2);
        assertEquals(repertoire.getUrgentKindPieces().size(), 2);
    }

    @Test
    void testAddBothKindDuplicatedPieces() {
        try {
            repertoire.addPiece(piece1);
            repertoire.addPiece(piece2);
            repertoire.addPiece(piece3);
            repertoire.addPiece(piece2);

        } catch (DupPiece dupPiece) {
            System.out.println("caught the duplication");
        }

        assertEquals(repertoire.getPieces().size(),3);
        assertEquals(repertoire.getRegularKindPieces().size(), 2);
        assertEquals(repertoire.getUrgentKindPieces().size(), 1);
    }


// //    TESTS FOR REGULAR

//    //TEST ADD
//    @Test
//    void testAddOneRegularPiece() {
//        try {
//            repertoire.addRegularPiece(regularPiece);
//        } catch (DupRegularPiece dupRegularPiece) {
//            fail("Should not have a duplication when there is no duplicated piece1");
//        }
//        assertEquals(repertoire.getRegularPieces().get(0).getName(), "chopin");
//        assertEquals(repertoire.getRegularPieces().get(0).getTitle(), "etude");
//        assertEquals(repertoire.getRegularPieces().get(0).getTempo(), 90);
//        assertEquals(repertoire.getRegularPieces().get(0).getTotalTime(), 10);
//    }

//    @Test
//    void testAddRegularPieceDuplicated() {
//        try {
//            repertoire.addRegularPiece(regularPiece);
//        } catch (DupRegularPiece dupRegularPiece) {
//            fail("Should not have a duplication when there is no duplicated piece");
//        }
//        try {
//            repertoire.addRegularPiece(regularPiece);
//        } catch (DupRegularPiece dupRegularPiece) {
//           // dupRegularPiece.printStackTrace();
//            //don't do anything because we are expecting to catch this exception
//            System.out.println("caught you!"); //or be a bit naughty
//        }
//        assertEquals(repertoire.getRegularPieces().get(repertoire.getRegularPieces().size() -1).getTitle(),
//                "etude");
//        assertTrue(repertoire.getRegularPieces().size() == 1);
//
//    }
//
//    //TEST GET
//    @Test
//    void getRegularPieces() {
//        try {
//            repertoire.addRegularPiece(regularPiece);
//        } catch (DupRegularPiece dupRegularPiece) {
//            fail("Should not have a duplication when there is no duplicated piece");
//        }
//        assertEquals(repertoire.getRegularPieces().get(0),regularPiece);
//    }
//
//
//
//
//    //TESTS FOR URGENT
//
//    //TEST ADD
//    @Test
//    void testAddOneUrgentPiece() {
//        try {
//            repertoire.addUrgentPiece(urgentPiece);
//        } catch (DupUrgentPiece dupUrgentPiece) {
//            fail("Should not have a duplication when there is no duplicated piece");
//        }
//        assertEquals(repertoire.getUrgentPieces().get(0).getName(), "bach");
//        assertEquals(repertoire.getUrgentPieces().get(0).getTitle(), "prelude");
//        assertEquals(repertoire.getUrgentPieces().get(0).getTempo(), 80);
//        assertEquals(repertoire.getUrgentPieces().get(0).getTotalTime(), 12);
//    }
//
//    // This test should not have exception thrown in the first add, but will have exception in the second add
//    @Test
//    void testAddUrgentPieceDuplicated() {
//        try {
//            repertoire.addUrgentPiece(urgentPiece);
//        } catch (DupUrgentPiece dupUrgentPiece) {
//            fail("Should not have a duplication when there is no duplicated piece");
//        }
//        try {
//            repertoire.addUrgentPiece(urgentPiece);
//        } catch (DupUrgentPiece dupUrgentPiece) {
////            dupUrgentPiece.printStackTrace();
//            //don't do anything because we are expecting to catch this exception
//            System.out.println("caught you!");
//        }
//
//        assertEquals(repertoire.getUrgentPieces().get(repertoire.getUrgentPieces().size() -1).getTitle(),
//                "prelude");
//        assertTrue(repertoire.getUrgentPieces().size() == 1);
//    }
//
//    //TEST URGENT
//    @Test
//    void getUrgentPieces() {
//        try {
//            repertoire.addUrgentPiece(urgentPiece);
//        } catch (DupUrgentPiece dupUrgentPiece) {
//            fail("Should not have a duplication when there is no duplicated piece");
//        }
//        assertEquals(repertoire.getUrgentPieces().get(0),urgentPiece);
//    }

}
