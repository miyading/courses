package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class ComposerPieceHashMapTest {

    ComposerPieceHashMap composerPieceHashMap;
    Composer chopin;
    Composer bach;
    Composer joplin;


    @BeforeEach
    void setUpTests() {
        composerPieceHashMap = new ComposerPieceHashMap();
        chopin = new Composer("chopin","romantic");
        bach  = new Composer("bach", "baroque");
        joplin = new Composer("joplin", "jazz");

    }

    @Test
    void testAddComposer() {
        assertEquals(composerPieceHashMap.printComposerPieces(chopin), "etude in c sharp minor");
    }
}
