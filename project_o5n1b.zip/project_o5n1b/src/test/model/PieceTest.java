package model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public abstract class PieceTest {
    protected Piece pieceTest;

    //    private String name;
    //    private String title;
    //    private int tempo; //speed
    //    private int totalTime;
    //

    @Test
    public void getNameTest() {
        assertEquals(pieceTest.getName(),"");

    }

    @Test
    public void getTitleTest() {
        assertEquals(pieceTest.getTitle(),"");

    }

    @Test
    public void getTempoTest() {
        assertEquals(pieceTest.getTempo(), 0);

    }

    @Test
    public void getTotalTimeTest() {
        assertEquals(pieceTest.getTotalTime(), 0);
    }

    @Test
    public void getKindTest() {
        assertEquals(pieceTest.getKind(), "");
    }
}
